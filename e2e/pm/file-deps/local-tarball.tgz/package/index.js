module.exports = { hello: "from-local-tarball" };
